package model;

import java.util.Vector;

public class Map {
    private String hostUsername;
    private String enemyUsername;
    public Cell[] left = new Cell[17];
    public Cell[] middle = new Cell[17];
    public Cell[] right = new Cell[17];

    public Map(String hostUsername, String enemyUsername) {
        for (int i = 0; i < 17; i++) {
            this.left[i] = new Cell();
            this.right[i] = new Cell();
            this.middle[i] = new Cell();
        }
        this.hostUsername = hostUsername;
        this.enemyUsername = enemyUsername;
        Castle leftCastle = new Castle("left", hostUsername);
        Castle middleCastle = new Castle("middle", hostUsername);
        Castle rightCastle = new Castle("right", hostUsername);
        this.left[0].addCastle(leftCastle);
        this.right[0].addCastle(rightCastle);
        this.middle[0].addCastle(middleCastle);
        Castle EnemyleftCastle = new Castle("left", enemyUsername);
        Castle EnemymiddleCastle = new Castle("middle", enemyUsername);
        Castle EnemyrightCastle = new Castle("right", enemyUsername);
        this.left[16].addCastle(EnemyleftCastle);
        this.middle[16].addCastle(EnemymiddleCastle);
        this.right[16].addCastle(EnemyrightCastle);
    }

    public Cell[] get(String direction) {
        if (direction.equals("left"))
            return left;
        else if (direction.equals("right"))
            return right;
        else
            return middle;
    }

    public Cell[] getMiddle() {
        return middle;
    }

    public Cell[] getRight() {
        return right;
    }

    public Cell[] getLeft() {
        return left;
    }
}
