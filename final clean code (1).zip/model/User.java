package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Vector;

public class User {
    private String username;
    private String password;
    private Integer level;
    private Integer experience;
    private Integer gold;
    private ArrayList<Cart> battleDeck = new ArrayList<>();
    private ArrayList<Cart> availableCart = new ArrayList<>();
    private static Vector<User> scoreBoard = new Vector<>();

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.level = 1;
        this.experience = 0;
        this.gold = 100;
        Cart Barbarian = new Cart("Barbarian", "troop", 2000, 900, 100, username);
        Cart Fireball = new Cart("Fireball", "spell", 0, 1600, 100, username);
        this.battleDeck.add(Fireball);
        this.battleDeck.add(Barbarian);
        scoreBoard.add(this);
    }

    public static void updateScoreBoard() {
        for (int i = 0; i < scoreBoard.size(); i++) {
            for (int j = i + 1; j < scoreBoard.size(); j++) {
                if (scoreBoard.get(j).level > scoreBoard.get(i).level)
                    Collections.swap(scoreBoard, i, j);
                else if (scoreBoard.get(i).level.equals(scoreBoard.get(j).level)) {
                    if (scoreBoard.get(j).experience > scoreBoard.get(i).experience)
                        Collections.swap(scoreBoard, i, j);
                    else if (scoreBoard.get(j).experience.equals(scoreBoard.get(i).experience))
                        if (scoreBoard.get(j).getUsername().compareTo(scoreBoard.get(i).getUsername()) < 0)
                            Collections.swap(scoreBoard, i, j);
                }
            }
        }
    }

    public static Vector<User> getScoreBoard() {
        return scoreBoard;
    }

    public String getUsername() {
        return username;
    }

    public Integer getLevel() {
        return level;
    }

    public Integer getGold() {
        return gold;
    }

    public Integer getExperience() {
        return experience;
    }

    public ArrayList<Cart> getBattleDeck() {
        return battleDeck;
    }

    public static void setPassword(String username, String newPassword) {
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                scoreBoard.get(i).password = newPassword;
                System.out.println("Password changed successfully!");
                break;
            }
        }
    }

    public static void showUser(String username) {
        updateScoreBoard();
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                System.out.println("username: " + username);
                System.out.println("password: " + scoreBoard.get(i).password);
                System.out.println("level: " + scoreBoard.get(i).level);
                System.out.println("experience: " + scoreBoard.get(i).experience);
                System.out.println("gold: " + scoreBoard.get(i).gold);
                System.out.println("rank: " + (i + 1));
            }
        }
    }

    public static void removeCartFromBattleDeck(String username, String cartName) {
        boolean found = false;
        Integer sizeOfBattleDeck = 0;
        Integer indexOfUser = 0;
        int indexOfCart = 0;
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                sizeOfBattleDeck = scoreBoard.get(i).battleDeck.size();
                indexOfUser = i;
                for (int j = 0; j < scoreBoard.get(i).battleDeck.size(); j++) {
                    if (scoreBoard.get(i).battleDeck.get(j).getCartName().equals(cartName)) {
                        indexOfCart = j;
                        found = true;
                    }
                }
            }
        }
        if (!found)
            System.out.println("This card isn't in your battle deck!");
        else if (sizeOfBattleDeck.equals(1))
            System.out.println("Invalid action: your battle deck will be empty!");
        else {
            System.out.println("Card " + scoreBoard.get(indexOfUser).battleDeck.get(indexOfCart).getCartName() + " removed successfully!");
            scoreBoard.get(indexOfUser).availableCart.add(scoreBoard.get(indexOfUser).battleDeck.get(indexOfCart));
            scoreBoard.get(indexOfUser).battleDeck.remove(indexOfCart);
        }
    }

    public static void AddCartToBattleDeck(String username, String cartName) {
        boolean foundInAvailable = false;
        boolean foundInDeck = false;
        Integer sizeOfDeck = 0;
        Integer indexOfUser = 0;
        int indexOfCart = 0;
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                for (int j = 0; j < scoreBoard.get(i).availableCart.size(); j++) {
                    if (scoreBoard.get(i).availableCart.get(j).getCartName().equals(cartName)) {
                        foundInAvailable = true;
                        indexOfCart = j;
                    }
                }
                sizeOfDeck = scoreBoard.get(i).battleDeck.size();
                indexOfUser = i;
                for (int j = 0; j < scoreBoard.get(i).battleDeck.size(); j++) {
                    if (scoreBoard.get(i).battleDeck.get(j).getCartName().equals(cartName)) {
                        foundInDeck = true;
                    }
                }
            }
        }
        if (foundInDeck)
            System.out.println("This card is already in your battle deck!");
        else if (!foundInAvailable)
            System.out.println("You don't have this card!");
        else if (sizeOfDeck.equals(4))
            System.out.println("Invalid action: your battle deck is full!");
        else {
            scoreBoard.get(indexOfUser).battleDeck.add(scoreBoard.get(indexOfUser).availableCart.get(indexOfCart));
            scoreBoard.get(indexOfUser).availableCart.remove(indexOfCart);
            System.out.println("Card " + cartName + " added successfully!");
        }
    }

    public static void showBattleDeck(String username) {
        ArrayList<String> cartNames = new ArrayList<>();
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                for (int j = 0; j < scoreBoard.get(i).battleDeck.size(); j++) {
                    cartNames.add(scoreBoard.get(i).battleDeck.get(j).getCartName());
                }
            }
        }
        String temp;
        for (int i = 0; i < cartNames.size(); i++) {
            for (int j = i + 1; j < cartNames.size(); j++) {
                if (cartNames.get(i).compareTo(cartNames.get(j)) > 0) {
                    temp = cartNames.get(i);
                    cartNames.set(i, cartNames.get(j));
                    cartNames.set(j, temp);
                }
            }
        }
        for (String cartName : cartNames) {
            System.out.println(cartName);
        }
    }

    public static void buyCard(String username, String cartName) {
        boolean haveThisCart = false;
        boolean haveEnoughGold = true;
        int indexOfUser = 0;
        Integer goldNeeded = 0;
        Cart cart = Cart.getCartById(cartName);
        goldNeeded = cart.price;
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                indexOfUser = i;
                if (scoreBoard.get(i).gold < goldNeeded) {
                    System.out.println("Not enough gold to buy " + cartName + "!");
                    haveEnoughGold = false;
                } else {
                    for (int j = 0; j < scoreBoard.get(i).battleDeck.size(); j++) {
                        if (scoreBoard.get(i).battleDeck.get(j).getCartName().equals(cartName))
                            haveThisCart = true;
                    }
                }
                break;
            }
        }
        if (haveEnoughGold && haveThisCart) {
            System.out.println("You have this card!");
        } else if (haveEnoughGold && !haveThisCart) {
            scoreBoard.get(indexOfUser).gold -= goldNeeded;
            Cart myCart = Cart.getCartById(cartName);
            myCart.setOwnerName(username);
            scoreBoard.get(indexOfUser).availableCart.add(myCart);
            System.out.println("Card " + cartName + " bought successfully!");
        }
    }

    public static void sellCard(String username, String cartName) {
        boolean IsCartAvailable = false;
        boolean isCartInBattle = false;
        int indexOfUser = 0;
        int indexOfCart = 0;
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                indexOfUser = i;
                for (int j = 0; j < scoreBoard.get(i).availableCart.size(); j++) {
                    if (scoreBoard.get(i).availableCart.get(j).getCartName().equals(cartName)) {
                        IsCartAvailable = true;
                        indexOfCart = j;
                    }
                }
                for (int j = 0; j < scoreBoard.get(i).battleDeck.size(); j++) {
                    if (scoreBoard.get(i).battleDeck.get(j).getCartName().equals(cartName))
                        isCartInBattle = true;
                }
                break;
            }
        }
        if (isCartInBattle)
            System.out.println("You cannot sell a card from your battle deck!");
        else if (!IsCartAvailable)
            System.out.println("You don't have this card!");
        else {
            scoreBoard.get(indexOfUser).availableCart.remove(indexOfCart);
            double goldAdded = Math.floor(Cart.getCartById(cartName).price.doubleValue() * 0.8);
            scoreBoard.get(indexOfUser).gold += (int) goldAdded;
            System.out.println("Card " + cartName + " sold successfully!");

        }
    }

    public static User getUserByUsername(String username) {
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                return scoreBoard.get(i);
            }
        }
        return null;
    }

    public static boolean hasCard(String username, String cartName) {
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                for (int j = 0; j < scoreBoard.get(i).getBattleDeck().size(); j++) {
                    if (scoreBoard.get(i).getBattleDeck().get(j).getCartName().equals(cartName))
                        return true;
                }
            }
        }
        return false;
    }

    public static void addExperience(String username, Integer experience) {
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                scoreBoard.get(i).experience += experience;
            }
        }
    }

    public static void addGold(String username, Integer Gold) {
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                scoreBoard.get(i).gold += Gold;
            }
        }
    }

    public static void updateLevel(String username) {
        for (int i = 0; i < scoreBoard.size(); i++) {
            if (scoreBoard.get(i).getUsername().equals(username)) {
                if (scoreBoard.get(i).experience >= 160 * (scoreBoard.get(i).getLevel()) * (scoreBoard.get(i).getLevel())) {
                    scoreBoard.get(i).experience -= 160 * (scoreBoard.get(i).getLevel()) * (scoreBoard.get(i).getLevel());
                    scoreBoard.get(i).level++;
                }
            }
        }
    }
}
