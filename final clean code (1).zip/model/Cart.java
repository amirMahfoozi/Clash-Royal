package model;

public class Cart {
    public String name;
    public String type;
    public Integer hitPoint;
    public Integer damage;
    public Integer price;
    public String ownerName;

    public Cart(String name, String type, Integer hitPoint, Integer damage, Integer price, String ownerName) {
        this.name = name;
        this.type = type;
        this.hitPoint = hitPoint;
        this.damage = damage;
        this.price = price;
        this.ownerName = ownerName;
    }

    public String getCartName() {
        return name;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public static Cart getCartById(String cartName) {
        if (cartName.equals("Barbarian"))
            return new Cart("Barbarian", "troop", 2000, 900, 100, "");
        else if (cartName.equals("Ice Wizard"))
            return new Cart("Ice Wizard", "troop", 3500, 1500, 180, "");
        else if (cartName.equals("Baby Dragon"))
            return new Cart("Baby Dragon", "troop", 3300, 1200, 200, "");
        else if (cartName.equals("Fireball"))
            return new Cart("Fireball", "spell", 0, 1600, 100, "");
        else if (cartName.equals("Heal"))
            return new Cart("Heal", "spell", 1999, 1000, 150, "");
        return null;
    }
}
