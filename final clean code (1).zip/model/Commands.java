package model;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public enum Commands {
    SHOW_CURRENT_MENU("^show current menu$"),
    REGISTER("^register username (.+?) password (.+?)$"),
    USERNAME_VALIDATION("^[A-Za-z]+$"),
    PASSWORD_VALIDATION("^(?=\\S*[A-Z])(?=\\S*[0-9])(?=\\S*[a-z])(?=\\S*[\\!\\@\\#\\$\\%\\^\\&\\*])\\S{8,20}$"),
    LOGIN("^login username (.+?) password (.+?)$"),
    EXIT("^Exit$"),
    LIST_OF_USERS("^list of users$"),
    SCOREBOARD("^scoreboard$"),
    BEGIN_WITH_DIGIT("^\\d+"),
    LOGOUT("^logout$"),
    PROFILE_MENU("^profile menu$"),
    SHOP_MENU("^shop menu$"),
    BACK("^back$"),
    CHANGE_PASSWORD("^change password old password (.+?) new password (.+?)$"),
    INFO("^Info$"),
    REMOVE_FROM_BATTLE_DECK("^remove from battle deck (.+?)$"),
    CART_VALIDATION("^(Fireball|Heal|Barbarian|Baby Dragon|Ice Wizard)$"),
    ADD_TO_BATTLE_DECK("^add to battle deck (.+?)$"),
    SHOW_BATTLE_DECK("^show battle deck$"),
    BUY_CARD("^buy card (.+?)$"),
    SELL_CARD("^sell card (.+?)$"),
    START_GAME("^start game turns count (\\-?\\d+) username (.+?)$"),
    SHOW_HITPOINT_OF_OPPONENT("^show the hitpoints left of my opponent$"),
    SHOW_LINE_INFO("^show line info (.+?)$"),
    DIRECTION("^(left|right|middle)$"),
    NUMBER_OF_CARDS("^number of cards to play$"),
    NUMBER_OF_MOVES("^number of moves left$"),
    MOVE_TROOP("^move troop in line (.+?) and row (\\d+) (.+?)$"),
    DEPLOY_TROOP("^deploy troop (.+?) in line (.+?) and row (\\d+)$"),
    DEPLOY_HEAL("^deploy spell Heal in line (.+?) and row (\\d+)$"),
    FIREBALL_DEPLOY("^deploy spell Fireball in line (.+?)$"),
    NEXT_TURN("^next turn$");

    private String regex;

    Commands(String regex) {
        this.regex = regex;
    }

    public static Matcher getMatcher(String input, Commands command) {
        Pattern pattern = Pattern.compile(command.regex);
        return pattern.matcher(input);
    }
}
