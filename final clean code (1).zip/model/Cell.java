package model;

import java.util.Vector;

public class Cell {
    private Vector<Cart> cartsInCell = new Vector<>();
    private Castle castle;

    public void fight(String host, String enemy, Integer row, Map map, String lineDirection) {
        Vector<Cart> hostCards = new Vector<>();
        Vector<Cart> enemyCards = new Vector<>();
        Vector<Cart> hostHeals = new Vector<>();
        Vector<Cart> enemyHeals = new Vector<>();
        for (int i = 0; i < this.getCartsInCell().size(); i++) {
            if (this.getCartsInCell().get(i).getOwnerName().equals(host) && !this.getCartsInCell().get(i).getCartName().equals("Heal"))
                hostCards.add(this.getCartsInCell().get(i));
            else if (this.getCartsInCell().get(i).getOwnerName().equals(enemy) && !this.getCartsInCell().get(i).getCartName().equals("Heal"))
                enemyCards.add(this.getCartsInCell().get(i));
            else if (this.getCartsInCell().get(i).getOwnerName().equals(host) && this.getCartsInCell().get(i).getCartName().equals("Heal"))
                hostHeals.add(this.getCartsInCell().get(i));
            else if (this.getCartsInCell().get(i).getOwnerName().equals(enemy) && this.getCartsInCell().get(i).getCartName().equals("Heal"))
                enemyHeals.add(this.getCartsInCell().get(i));
        }
        for (int i = 0; i < hostCards.size(); i++) {
            for (int j = 0; j < enemyCards.size(); j++) {
                if (hostCards.get(i).damage > enemyCards.get(j).damage)
                    enemyCards.get(j).hitPoint -= hostCards.get(i).damage - enemyCards.get(j).damage;
                else
                    hostCards.get(i).hitPoint -= enemyCards.get(j).damage - hostCards.get(i).damage;
            }
        }
        if (row.equals(15)) {
            if (map.get(lineDirection)[16].getCastle().getHitPoint() > 0) {
                for (int i = 0; i < hostCards.size(); i++) {
                    map.get(lineDirection)[16].getCastle().setHitPoint(map.get(lineDirection)[16].getCastle().getHitPoint() - hostCards.get(i).damage);
                    hostCards.get(i).hitPoint -= map.get(lineDirection)[16].getCastle().getDamage();
                }
            }
        }
        if (row.equals(1)) {
            if (map.get(lineDirection)[0].getCastle().getHitPoint() > 0) {
                for (int i = 0; i < enemyCards.size(); i++) {
                    map.get(lineDirection)[0].getCastle().setHitPoint(map.get(lineDirection)[0].getCastle().getHitPoint() - enemyCards.get(i).damage);
                    enemyCards.get(i).hitPoint -= map.get(lineDirection)[0].getCastle().getDamage();
                }
            }
        }
        Healing(hostCards, hostHeals);
        Healing(enemyCards, enemyHeals);
        for (int i = 0; i < this.getCartsInCell().size(); i++) {
            if (this.getCartsInCell().get(i).hitPoint <= 0) {
                this.getCartsInCell().remove(i);
                i--;
            }
        }
        if (map.getMiddle()[0].getCastle().getHitPoint() < 0)
            map.getMiddle()[0].getCastle().setHitPoint(0);
        if (map.getLeft()[0].getCastle().getHitPoint() < 0)
            map.getLeft()[0].getCastle().setHitPoint(0);
        if (map.getRight()[0].getCastle().getHitPoint() < 0)
            map.getRight()[0].getCastle().setHitPoint(0);
        if (map.getMiddle()[16].getCastle().getHitPoint() < 0)
            map.getMiddle()[16].getCastle().setHitPoint(0);
        if (map.getRight()[16].getCastle().getHitPoint() < 0)
            map.getRight()[16].getCastle().setHitPoint(0);
        if (map.getLeft()[16].getCastle().getHitPoint() < 0)
            map.getLeft()[16].getCastle().setHitPoint(0);
    }

    private void Healing(Vector<Cart> enemyCards, Vector<Cart> enemyHeals) {
        for (Cart enemyHeal : enemyHeals) {
            for (Cart enemyCard : enemyCards) {
                enemyCard.hitPoint += enemyHeal.damage;
                if (enemyCard.hitPoint > Cart.getCartById(enemyCard.getCartName()).hitPoint)
                    enemyCard.hitPoint = Cart.getCartById(enemyCard.getCartName()).hitPoint;
            }
            enemyHeal.hitPoint -= 1000;
        }
    }

    public void addTroops(Cart cart) {
        this.cartsInCell.add(cart);
    }

    public void addCastle(Castle castle) {
        this.castle = castle;
    }

    public Castle getCastle() {
        return castle;
    }

    public Vector<Cart> getCartsInCell() {
        return cartsInCell;
    }
}
