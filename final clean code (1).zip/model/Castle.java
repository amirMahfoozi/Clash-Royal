package model;

public class Castle {
    private String location;
    private Integer hitPoint;
    private Integer damage;

    public Castle(String location, String username) {
        this.damage = User.getUserByUsername(username).getLevel() * 500;
        this.location = location;
        if (location.equals("right")) {
            this.hitPoint = User.getUserByUsername(username).getLevel() * 2500;
        } else if (location.equals("left")) {
            this.hitPoint = User.getUserByUsername(username).getLevel() * 2500;
        } else {
            this.hitPoint = User.getUserByUsername(username).getLevel() * 3600;
        }
    }

    public Integer getHitPoint() {
        return hitPoint;
    }

    public void setHitPoint(Integer hitPoint) {
        this.hitPoint = hitPoint;
    }

    public Integer getDamage() {
        return damage;
    }
}
