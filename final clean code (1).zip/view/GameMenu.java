package view;

import controller.Controller;
import model.*;

import java.util.regex.Matcher;

public class GameMenu {
    private Controller controller;

    public GameMenu(Controller controller) {
        this.controller = controller;
    }

    private String hostUsername;
    private String enemyUsername;
    private Integer rounds;
    private boolean isHostPlaying;

    public void run() {
        hostUsername = LoginMenu.LoggedInUsername;
        enemyUsername = MainMenu.EnemyUsername;
        rounds = MainMenu.rounds;
        Map map = new Map(hostUsername, enemyUsername);
        isHostPlaying = true;
        int numberOfCardsToPlay = 1;
        int numberOfMove = 3;
        String line = Menu.getScanner().nextLine();
        for (int i = 0; i < 2 * rounds; i++) {
            numberOfCardsToPlay = 1;
            numberOfMove = 3;
            while (true) {
                Matcher matcherShowLineInfo = Commands.getMatcher(line, Commands.SHOW_LINE_INFO);
                Matcher matcherMoveTroop = Commands.getMatcher(line, Commands.MOVE_TROOP);
                Matcher matcherDeployTroop = Commands.getMatcher(line, Commands.DEPLOY_TROOP);
                Matcher matcherHeal = Commands.getMatcher(line, Commands.DEPLOY_HEAL);
                Matcher matcherFireBall = Commands.getMatcher(line, Commands.FIREBALL_DEPLOY);
                if (Commands.getMatcher(line, Commands.SHOW_HITPOINT_OF_OPPONENT).find()) {
                    Controller.GameMethods.showHitPointOfOpponent(map, isHostPlaying);
                } else if (matcherShowLineInfo.find()) {
                    Controller.GameMethods.showLineInfo(matcherShowLineInfo, map);
                } else if (Commands.getMatcher(line, Commands.NUMBER_OF_CARDS).find())
                    System.out.println("You can play " + numberOfCardsToPlay + " cards more!");
                else if (Commands.getMatcher(line, Commands.NUMBER_OF_MOVES).find())
                    System.out.println("You have " + numberOfMove + " moves left!");
                else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find())
                    System.out.println("Game Menu");
                else if (matcherMoveTroop.find()) {
                    numberOfMove = Controller.GameMethods.moveTroop(matcherMoveTroop, map, numberOfMove, isHostPlaying, hostUsername, enemyUsername);
                } else if (matcherDeployTroop.find()) {
                    numberOfCardsToPlay = Controller.GameMethods.deployTroop(matcherDeployTroop, hostUsername, enemyUsername, isHostPlaying, numberOfCardsToPlay, map);
                } else if (matcherHeal.find()) {
                    numberOfCardsToPlay = Controller.GameMethods.deployHeal(matcherHeal, hostUsername, enemyUsername, isHostPlaying, map, numberOfCardsToPlay);
                } else if (matcherFireBall.find()) {
                    numberOfCardsToPlay = Controller.GameMethods.deployFireball(matcherFireBall, hostUsername, enemyUsername, map, isHostPlaying, numberOfCardsToPlay);
                } else if (Commands.getMatcher(line, Commands.NEXT_TURN).find()) {
                    if (i % 2 != 0) {
                        for (int j = 1; j < 16; j++) {
                            map.getLeft()[j].fight(hostUsername, enemyUsername, j, map, "left");
                            map.getRight()[j].fight(hostUsername, enemyUsername, j, map, "right");
                            map.getMiddle()[j].fight(hostUsername, enemyUsername, j, map, "middle");
                        }
                    }
                    if (i != 2 * rounds - 1 && !(Controller.GameMethods.gameEnded(map) && i % 2 != 0)) {
                        if (isHostPlaying) {
                            System.out.println("Player " + enemyUsername + " is now playing!");
                        } else {
                            System.out.println("Player " + hostUsername + " is now playing!");
                        }
                        line = Menu.getScanner().nextLine();
                    }
                    break;
                } else {
                    System.out.println("Invalid command!");
                }
                line = Menu.getScanner().nextLine();
            }
            if (isHostPlaying)
                isHostPlaying = false;
            else
                isHostPlaying = true;
            if (Controller.GameMethods.gameEnded(map) && i % 2 != 0)
                i = 2 * rounds;
        }
        Controller.GameMethods.gameAnalise(map, hostUsername, enemyUsername);
    }
}
