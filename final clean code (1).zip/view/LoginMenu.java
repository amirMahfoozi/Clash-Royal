package view;

import controller.Controller;
import model.Commands;

import java.util.Vector;
import java.util.regex.Matcher;

public class LoginMenu {
    private Controller controller;
    public static Vector<String> allUsername = new Vector<>();
    public static Vector<String> allPassword = new Vector<>();
    public static String LoggedInUsername;
    public static String LoggedInPassword;

    public LoginMenu(Controller controller) {
        this.controller = controller;
    }

    public String run() {
        String line = Menu.getScanner().nextLine();
        while (true) {
            Matcher matcherRegister = Commands.getMatcher(line, Commands.REGISTER);
            Matcher matcherLogin = Commands.getMatcher(line, Commands.LOGIN);
            if (matcherRegister.find()) {
                Controller.LoginMethods.register(matcherRegister, allUsername, allPassword);
            } else if (matcherLogin.find()) {
                String output = Controller.LoginMethods.login(matcherLogin, allUsername, allPassword);
                if (output != null)
                    return output;
            } else if (Commands.getMatcher(line, Commands.EXIT).find())
                System.exit(0);
            else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find())
                System.out.println("Register/Login Menu");
            else {
                System.out.println("Invalid command!");
            }
            line = Menu.getScanner().nextLine();
        }
    }

    public static Vector<String> getAllUsername() {
        return allUsername;
    }
}
