package view;

import controller.Controller;
import model.Commands;

import java.util.regex.Matcher;

public class ProfileMenu {
    private Controller controller;
    private String LoggedInUsername;
    private String LoggedInPassword;

    public ProfileMenu(Controller controller) {
        this.controller = controller;
    }

    public String run() {
        LoggedInUsername = LoginMenu.LoggedInUsername;
        LoggedInPassword = LoginMenu.LoggedInPassword;
        String line = Menu.getScanner().nextLine();
        while (true) {
            Matcher matcherChangePassword = Commands.getMatcher(line, Commands.CHANGE_PASSWORD);
            Matcher matcherRemoveFromBattleDeck = Commands.getMatcher(line, Commands.REMOVE_FROM_BATTLE_DECK);
            Matcher matcherAddToBattleDeck = Commands.getMatcher(line, Commands.ADD_TO_BATTLE_DECK);
            if (Commands.getMatcher(line, Commands.BACK).find()) {
                System.out.println("Entered main menu!");
                return "main menu";
            } else if (matcherChangePassword.find()) {
                Controller.ProfileMethods.changePassword(matcherChangePassword, LoggedInPassword, LoggedInUsername);
            } else if (Commands.getMatcher(line, Commands.INFO).find()) {
                Controller.ProfileMethods.info(LoggedInUsername);
            } else if (matcherRemoveFromBattleDeck.find()) {
                Controller.ProfileMethods.removeFromBattleDeck(matcherRemoveFromBattleDeck, LoggedInUsername);
            } else if (matcherAddToBattleDeck.find()) {
                Controller.ProfileMethods.addToBattleDeck(matcherAddToBattleDeck, LoggedInUsername);
            } else if (Commands.getMatcher(line, Commands.SHOW_BATTLE_DECK).find()) {
                Controller.ProfileMethods.showBattleDeck(LoggedInUsername);
            } else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find())
                System.out.println("Profile Menu");
            else {
                System.out.println("Invalid command!");
            }
            line = Menu.getScanner().nextLine();
        }
    }
}
