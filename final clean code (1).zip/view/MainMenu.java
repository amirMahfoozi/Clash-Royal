package view;

import controller.Controller;
import model.Commands;
import model.User;

import java.net.UnknownServiceException;
import java.util.regex.Matcher;

public class MainMenu {
    private Controller controller;
    private String LoggedInUsername;
    private String LoggedInPassword;
    public static String EnemyUsername;
    public static Integer rounds;

    public MainMenu(Controller controller) {
        this.controller = controller;
    }

    public String run() {
        LoggedInUsername = LoginMenu.LoggedInUsername;
        LoggedInPassword = LoginMenu.LoggedInPassword;
        String line = Menu.getScanner().nextLine();
        while (true) {
            Matcher matcherListOfUser = Commands.getMatcher(line, Commands.LIST_OF_USERS);
            Matcher matcherScoreBoard = Commands.getMatcher(line, Commands.SCOREBOARD);
            Matcher matcherStartGame = Commands.getMatcher(line, Commands.START_GAME);
            if (matcherListOfUser.find()) {
                for (int i = 0; i < LoginMenu.getAllUsername().size(); i++) {
                    System.out.println("user " + (i + 1) + ": " + LoginMenu.getAllUsername().get(i));
                }
            } else if (matcherScoreBoard.find()) {
                User.updateScoreBoard();
                int minimumNumber = 5;
                if (User.getScoreBoard().size() < 5)
                    minimumNumber = User.getScoreBoard().size();
                for (int i = 0; i < minimumNumber; i++) {
                    System.out.println((i + 1) + "- username: " + User.getScoreBoard().get(i).getUsername() + " level: " + User.getScoreBoard().get(i).getLevel() + " experience: " + User.getScoreBoard().get(i).getExperience());
                }
            } else if (Commands.getMatcher(line, Commands.LOGOUT).find()) {
                System.out.println("User " + LoggedInUsername + " logged out successfully!");
                return "logged out";
            } else if (Commands.getMatcher(line, Commands.PROFILE_MENU).find()) {
                System.out.println("Entered profile menu!");
                return "profile menu";
            } else if (Commands.getMatcher(line, Commands.SHOP_MENU).find()) {
                System.out.println("Entered shop menu!");
                return "shop menu";
            } else if (matcherStartGame.find()) {
                Integer turnsCount = Integer.valueOf(matcherStartGame.group(1));
                String usernameToFight = matcherStartGame.group(2);
                if (turnsCount < 5 || turnsCount > 30)
                    System.out.println("Invalid turns count!");
                else if (!Commands.getMatcher(usernameToFight, Commands.USERNAME_VALIDATION).find())
                    System.out.println("Incorrect format for username!");
                else if (!LoginMenu.allUsername.contains(usernameToFight))
                    System.out.println("Username doesn't exist!");
                else {
                    System.out.println("Battle started with user " + usernameToFight);
                    EnemyUsername = usernameToFight;
                    rounds = turnsCount;
                    return "game menu";
                }
            } else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find())
                System.out.println("Main Menu");
            else {
                System.out.println("Invalid command!");
            }
            line = Menu.getScanner().nextLine();
        }
    }
}
