package view;

import controller.Controller;
import model.Commands;

import java.util.regex.Matcher;

public class ShopMenu {
    private Controller controller;
    private String LoggedInUsername;
    private String LoggedInPassword;

    public ShopMenu(Controller controller) {
        this.controller = controller;
    }

    public String run() {
        String line = Menu.getScanner().nextLine();
        LoggedInUsername = LoginMenu.LoggedInUsername;
        LoggedInPassword = LoginMenu.LoggedInPassword;
        while (true) {
            Matcher matcherBuyCard = Commands.getMatcher(line, Commands.BUY_CARD);
            Matcher matcherSellCard = Commands.getMatcher(line, Commands.SELL_CARD);
            if (Commands.getMatcher(line, Commands.BACK).find()) {
                System.out.println("Entered main menu!");
                return "main menu";
            } else if (matcherBuyCard.find()) {
                Controller.ShopMethods.buyCard(matcherBuyCard, LoggedInUsername);
            } else if (matcherSellCard.find()) {
                Controller.ShopMethods.sellCard(matcherSellCard, LoggedInUsername);
            } else if (Commands.getMatcher(line, Commands.SHOW_CURRENT_MENU).find())
                System.out.println("Shop Menu");
            else {
                System.out.println("Invalid command!");
            }
            line = Menu.getScanner().nextLine();
        }
    }
}
