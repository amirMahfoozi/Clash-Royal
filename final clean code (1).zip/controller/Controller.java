package controller;

import model.Cart;
import model.Commands;
import model.Map;
import model.User;
import view.*;

import java.util.Vector;
import java.util.regex.Matcher;

public class Controller {
    private final GameMenu gameMenu;
    private final LoginMenu loginMenu;
    private final MainMenu mainMenu;
    private final ProfileMenu profileMenu;
    private final ShopMenu shopMenu;

    public Controller() {
        gameMenu = new GameMenu(this);
        loginMenu = new LoginMenu(this);
        mainMenu = new MainMenu(this);
        profileMenu = new ProfileMenu(this);
        shopMenu = new ShopMenu(this);
    }

    public void run() {
        while (true) {
            if (loginMenu.run().equals("logged in")) {
                while (true) {
                    String outputMainMenu = mainMenu.run();
                    if (outputMainMenu.equals("logged out"))
                        break;
                    else if (outputMainMenu.equals("profile menu"))
                        profileMenu.run();
                    else if (outputMainMenu.equals("shop menu")) {
                        shopMenu.run();
                    } else if (outputMainMenu.equals("game menu")) {
                        gameMenu.run();
                    }
                }
            }
        }
    }

    public static class GameMethods {
        public static void showHitPointOfOpponent(Map map, boolean isHostPlaying) {
            if (isHostPlaying) {
                if (map.middle[16].getCastle().getHitPoint() > 0)
                    System.out.println("middle castle: " + map.middle[16].getCastle().getHitPoint());
                else
                    System.out.println("middle castle: -1");
                if (map.left[16].getCastle().getHitPoint() > 0)
                    System.out.println("left castle: " + map.left[16].getCastle().getHitPoint());
                else
                    System.out.println("left castle: -1");
                if (map.right[16].getCastle().getHitPoint() > 0)
                    System.out.println("right castle: " + map.right[16].getCastle().getHitPoint());
                else
                    System.out.println("right castle: -1");
            }
            if (!isHostPlaying) {
                if (map.middle[0].getCastle().getHitPoint() > 0)
                    System.out.println("middle castle: " + map.middle[0].getCastle().getHitPoint());
                else
                    System.out.println("middle castle: -1");
                if (map.left[0].getCastle().getHitPoint() > 0)
                    System.out.println("left castle: " + map.left[0].getCastle().getHitPoint());
                else
                    System.out.println("left castle: -1");
                if (map.right[0].getCastle().getHitPoint() > 0)
                    System.out.println("right castle: " + map.right[0].getCastle().getHitPoint());
                else
                    System.out.println("right castle: -1");
            }
        }

        public static void showLineInfo(Matcher matcherShowLineInfo, Map map) {
            String direction = matcherShowLineInfo.group(1);
            if (!Commands.getMatcher(direction, Commands.DIRECTION).find())
                System.out.println("Incorrect line direction!");
            else {
                System.out.println(direction + " line:");
                for (int j = 1; j < 16; j++) {
                    if (!map.get(direction)[j].getCartsInCell().isEmpty()) {
                        for (int k = 0; k < map.get(direction)[j].getCartsInCell().size(); k++) {
                            System.out.println("row " + j + ": " + map.get(direction)[j].getCartsInCell().get(k).getCartName() + ": " + map.get(direction)[j].getCartsInCell().get(k).getOwnerName());
                        }
                    }
                }
            }
        }

        public static int moveTroop(Matcher matcherMoveTroop, Map map, int numberOfMove, boolean isHostPlaying, String hostUsername, String enemyUsername) {
            String lineDirection = matcherMoveTroop.group(1);
            Integer row = Integer.valueOf(matcherMoveTroop.group(2));
            String direction = matcherMoveTroop.group(3);
            if (!Commands.getMatcher(lineDirection, Commands.DIRECTION).find())
                System.out.println("Incorrect line direction!");
            else if (row > 15 || row < 1)
                System.out.println("Invalid row number!");
            else if (!direction.equals("upward") && !direction.equals("downward"))
                System.out.println("you can only move troops upward or downward!");
            else if (numberOfMove <= 0)
                System.out.println("You are out of moves!");
            else {
                boolean found = false;
                boolean valid = true;
                int indexOfCart = 0;
                for (int j = 0; j < map.get(lineDirection)[row].getCartsInCell().size(); j++) {
                    if (isHostPlaying && map.get(lineDirection)[row].getCartsInCell().get(j).getOwnerName().equals(hostUsername) && !map.get(lineDirection)[row].getCartsInCell().get(j).getCartName().equals("Heal")) {
                        indexOfCart = j;
                        found = true;
                        if (row.equals(15) && direction.equals("upward")) {
                            System.out.println("Invalid move!");
                            valid = false;
                        }
                        if (row.equals(1) && direction.equals("downward")) {
                            System.out.println("Invalid move!");
                            valid = false;
                        }
                        break;
                    } else if (!isHostPlaying && map.get(lineDirection)[row].getCartsInCell().get(j).getOwnerName().equals(enemyUsername) && !map.get(lineDirection)[row].getCartsInCell().get(j).getCartName().equals("Heal")) {
                        indexOfCart = j;
                        found = true;
                        if (row.equals(15) && direction.equals("upward")) {
                            System.out.println("Invalid move!");
                            valid = false;
                        }
                        if (row.equals(1) && direction.equals("downward")) {
                            System.out.println("Invalid move!");
                            valid = false;
                        }
                        break;
                    }
                }
                if (!found)
                    System.out.println("You don't have any troops in this place!");
                else if (valid) {
                    if (direction.equals("upward")) {
                        map.get(lineDirection)[row + 1].addTroops(map.get(lineDirection)[row].getCartsInCell().get(indexOfCart));
                        numberOfMove--;
                        System.out.println(map.get(lineDirection)[row].getCartsInCell().get(indexOfCart).getCartName() + " moved successfully to row " + (row + 1) + " in line " + lineDirection);
                    } else {
                        numberOfMove--;
                        map.get(lineDirection)[row - 1].addTroops(map.get(lineDirection)[row].getCartsInCell().get(indexOfCart));
                        System.out.println(map.get(lineDirection)[row].getCartsInCell().get(indexOfCart).getCartName() + " moved successfully to row " + (row - 1) + " in line " + lineDirection);
                    }
                    map.get(lineDirection)[row].getCartsInCell().remove(indexOfCart);
                }
            }
            return numberOfMove;
        }

        public static boolean gameEnded(Map map) {
            if (map.getMiddle()[0].getCastle().getHitPoint() <= 0 &&
                    map.getRight()[0].getCastle().getHitPoint() <= 0 &&
                    map.getLeft()[0].getCastle().getHitPoint() <= 0)
                return true;
            if (map.getMiddle()[16].getCastle().getHitPoint() <= 0 &&
                    map.getRight()[16].getCastle().getHitPoint() <= 0 &&
                    map.getLeft()[16].getCastle().getHitPoint() <= 0)
                return true;
            return false;
        }

        public static int deployTroop(Matcher matcherDeployTroop, String hostUsername, String enemyUsername, boolean isHostPlaying, int numberOfCardsToPlay, Map map) {
            String troopName = matcherDeployTroop.group(1);
            String lineDirection = matcherDeployTroop.group(2);
            Integer row = Integer.valueOf(matcherDeployTroop.group(3));
            if (!Commands.getMatcher(troopName, Commands.CART_VALIDATION).find())
                System.out.println("Invalid troop name!");
            else if (troopName.equals("Heal") || troopName.equals("Fireball"))
                System.out.println("Invalid troop name!");
            else if (isHostPlaying && !User.hasCard(hostUsername, troopName))
                System.out.println("You don't have " + troopName + " card in your battle deck!");
            else if (!isHostPlaying && !User.hasCard(enemyUsername, troopName))
                System.out.println("You don't have " + troopName + " card in your battle deck!");
            else if (!Commands.getMatcher(lineDirection, Commands.DIRECTION).find())
                System.out.println("Incorrect line direction!");
            else if (row > 15 || row < 1)
                System.out.println("Invalid row number!");
            else if (isHostPlaying && row > 4)
                System.out.println("Deploy your troops near your castles!");
            else if (!isHostPlaying && row < 12)
                System.out.println("Deploy your troops near your castles!");
            else if (numberOfCardsToPlay <= 0)
                System.out.println("You have deployed a troop or spell this turn!");
            else {
                numberOfCardsToPlay--;
                System.out.println("You have deployed " + troopName + " successfully!");
                Cart cart = Cart.getCartById(troopName);
                if (isHostPlaying)
                    cart.setOwnerName(hostUsername);
                else
                    cart.setOwnerName(enemyUsername);

                map.get(lineDirection)[row].getCartsInCell().add(cart);
            }
            return numberOfCardsToPlay;
        }

        public static int deployHeal(Matcher matcherHeal, String hostUsername, String enemyUsername, boolean isHostPlaying, Map map, int numberOfCardsToPlay) {
            String lineDirection = matcherHeal.group(1);
            Integer row = Integer.valueOf(matcherHeal.group(2));
            if (!Commands.getMatcher(lineDirection, Commands.DIRECTION).find())
                System.out.println("Incorrect line direction!");
            else if (isHostPlaying && !User.hasCard(hostUsername, "Heal"))
                System.out.println("You don't have Heal card in your battle deck!");
            else if (!isHostPlaying && !User.hasCard(enemyUsername, "Heal"))
                System.out.println("You don't have Heal card in your battle deck!");
            else if (row > 15 || row < 1)
                System.out.println("Invalid row number!");
            else if (numberOfCardsToPlay <= 0)
                System.out.println("You have deployed a troop or spell this turn!");
            else {
                numberOfCardsToPlay--;
                System.out.println("You have deployed Heal successfully!");
                Cart cart = Cart.getCartById("Heal");
                if (isHostPlaying)
                    cart.setOwnerName(hostUsername);
                else
                    cart.setOwnerName(enemyUsername);
                map.get(lineDirection)[row].getCartsInCell().add(cart);
            }
            return numberOfCardsToPlay;
        }

        public static int deployFireball(Matcher matcherFireBall, String hostUsername, String enemyUsername, Map map, boolean isHostPlaying, int numberOfCardsToPlay) {
            String lineDirection = matcherFireBall.group(1);
            if (!Commands.getMatcher(lineDirection, Commands.DIRECTION).find())
                System.out.println("Incorrect line direction!");
            else if (isHostPlaying && !User.hasCard(hostUsername, "Fireball"))
                System.out.println("You don't have Fireball card in your battle deck!");
            else if (!isHostPlaying && !User.hasCard(enemyUsername, "Fireball"))
                System.out.println("You don't have Fireball card in your battle deck!");
            else if (numberOfCardsToPlay <= 0)
                System.out.println("You have deployed a troop or spell this turn!");
            else if (isHostPlaying) {
                if (map.get(lineDirection)[16].getCastle().getHitPoint().equals(0))
                    System.out.println("This castle is already destroyed!");
                else {
                    map.get(lineDirection)[16].getCastle().setHitPoint(map.get(lineDirection)[16].getCastle().getHitPoint() - 1600);
                    numberOfCardsToPlay--;
                    System.out.println("You have deployed Fireball successfully!");
                }
            } else {
                if (map.get(lineDirection)[0].getCastle().getHitPoint().equals(0))
                    System.out.println("This castle is already destroyed!");
                else {
                    map.get(lineDirection)[0].getCastle().setHitPoint(map.get(lineDirection)[0].getCastle().getHitPoint() - 1600);
                    numberOfCardsToPlay--;
                    System.out.println("You have deployed Fireball successfully!");
                }
            }
            return numberOfCardsToPlay;
        }

        public static void gameAnalise(Map map, String hostUsername, String enemyUsername) {
            int numberOfTowersEnemy = 0;
            int numberOfTowersHost = 0;
            if (map.getMiddle()[0].getCastle().getHitPoint().equals(0))
                numberOfTowersHost++;
            if (map.getRight()[0].getCastle().getHitPoint().equals(0))
                numberOfTowersHost++;
            if (map.getLeft()[0].getCastle().getHitPoint().equals(0))
                numberOfTowersHost++;
            if (map.getMiddle()[16].getCastle().getHitPoint().equals(0))
                numberOfTowersEnemy++;
            if (map.getRight()[16].getCastle().getHitPoint().equals(0))
                numberOfTowersEnemy++;
            if (map.getLeft()[16].getCastle().getHitPoint().equals(0))
                numberOfTowersEnemy++;
            int hostExperience = 0;
            int enemyExperience = 0;
            hostExperience += map.getMiddle()[0].getCastle().getHitPoint() + map.getRight()[0].getCastle().getHitPoint() + map.getLeft()[0].getCastle().getHitPoint();
            enemyExperience += map.getMiddle()[16].getCastle().getHitPoint() + map.getRight()[16].getCastle().getHitPoint() + map.getLeft()[16].getCastle().getHitPoint();
            User.addGold(hostUsername, numberOfTowersEnemy * 25);
            User.addGold(enemyUsername, numberOfTowersHost * 25);
            User.addExperience(hostUsername, hostExperience);
            User.addExperience(enemyUsername, enemyExperience);
            for (int i = 0; i < 30; i++) {
                User.updateLevel(hostUsername);
                User.updateLevel(enemyUsername);
            }
            if (hostExperience > enemyExperience)
                System.out.println("Game has ended. Winner: " + hostUsername);
            else if (hostExperience < enemyExperience)
                System.out.println("Game has ended. Winner: " + enemyUsername);
            else {
                System.out.println("Game has ended. Result: Tie");
            }
        }
    }

    public static class LoginMethods {
        public static void register(Matcher matcherRegister, Vector<String> allUsername, Vector<String> allPassword) {
            String username = matcherRegister.group(1);
            String password = matcherRegister.group(2);
            if (!Commands.getMatcher(username, Commands.USERNAME_VALIDATION).find())
                System.out.println("Incorrect format for username!");
            else if (!Commands.getMatcher(password, Commands.PASSWORD_VALIDATION).find())
                System.out.println("Incorrect format for password!");
            else if (Commands.getMatcher(password, Commands.BEGIN_WITH_DIGIT).find())
                System.out.println("Incorrect format for password!");
            else if (allUsername.contains(username))
                System.out.println("Username already exists!");
            else {
                allUsername.add(username);
                allPassword.add(password);
                new User(username, password);
                System.out.println("User " + username + " created successfully!");
            }
        }

        public static String login(Matcher matcherLogin, Vector<String> allUsername, Vector<String> allPassword) {
            String username = matcherLogin.group(1);
            String password = matcherLogin.group(2);
            if (!Commands.getMatcher(username, Commands.USERNAME_VALIDATION).find())
                System.out.println("Incorrect format for username!");
            else if (!Commands.getMatcher(password, Commands.PASSWORD_VALIDATION).find())
                System.out.println("Incorrect format for password!");
            else if (Commands.getMatcher(password, Commands.BEGIN_WITH_DIGIT).find())
                System.out.println("Incorrect format for password!");
            else if (!allUsername.contains(username))
                System.out.println("Username doesn't exist!");

            else if (!allPassword.get(allUsername.indexOf(username)).equals(password))
                System.out.println("Password is incorrect!");
            else {
                System.out.println("User " + username + " logged in!");
                LoginMenu.LoggedInUsername = username;
                LoginMenu.LoggedInPassword = password;
                return "logged in";
            }
            return null;
        }
    }

    public static class ProfileMethods {
        public static void changePassword(Matcher matcherChangePassword, String LoggedInPassword, String LoggedInUsername) {
            String password = matcherChangePassword.group(1);
            String newPassword = matcherChangePassword.group(2);
            if (!password.equals(LoggedInPassword))
                System.out.println("Incorrect password!");
            else if (!Commands.getMatcher(newPassword, Commands.PASSWORD_VALIDATION).find())
                System.out.println("Incorrect format for new password!");
            else if (Commands.getMatcher(newPassword, Commands.BEGIN_WITH_DIGIT).find())
                System.out.println("Incorrect format for new password!");
            else {
                LoginMenu.allPassword.set(LoginMenu.allUsername.indexOf(LoggedInUsername), newPassword);
                User.setPassword(LoggedInUsername, newPassword);
            }
        }

        public static void info(String LoggedInUsername) {
            User.showUser(LoggedInUsername);
        }

        public static void removeFromBattleDeck(Matcher matcherRemoveFromBattleDeck, String LoggedInUsername) {
            String cartName = matcherRemoveFromBattleDeck.group(1);
            if (!Commands.getMatcher(cartName, Commands.CART_VALIDATION).find())
                System.out.println("Invalid card name!");
            else {
                User.removeCartFromBattleDeck(LoggedInUsername, cartName);
            }
        }

        public static void addToBattleDeck(Matcher matcherAddToBattleDeck, String LoggedInUsername) {
            String cartName = matcherAddToBattleDeck.group(1);
            if (!Commands.getMatcher(cartName, Commands.CART_VALIDATION).find())
                System.out.println("Invalid card name!");
            else {
                User.AddCartToBattleDeck(LoggedInUsername, cartName);
            }
        }

        public static void showBattleDeck(String LoggedInUsername) {
            User.showBattleDeck(LoggedInUsername);
        }
    }

    public static class ShopMethods {
        public static void buyCard(Matcher matcherBuyCard, String LoggedInUsername) {
            String cartName = matcherBuyCard.group(1);
            if (!Commands.getMatcher(cartName, Commands.CART_VALIDATION).find())
                System.out.println("Invalid card name!");
            else {
                User.buyCard(LoggedInUsername, cartName);
            }
        }

        public static void sellCard(Matcher matcherSellCard, String LoggedInUsername) {
            String cartName = matcherSellCard.group(1);
            if (!Commands.getMatcher(cartName, Commands.CART_VALIDATION).find())
                System.out.println("Invalid card name!");
            else {
                User.sellCard(LoggedInUsername, cartName);
            }
        }
    }
}
